
print("Sports Tournament Ranking System")

teams = []
points = []
scores = []

n = int(input("Enter number of teams: "))

for i in range(n):
    name = input("Enter team name: ")
    teams.append(name)
    points.append(0)
    scores.append(0)

matches = int(input("Enter number of matches: "))

for i in range(matches):
    print("\nMatch", i + 1)

    t1 = int(input("Enter first team number (1 to n): ")) - 1
    t2 = int(input("Enter second team number (1 to n): ")) - 1

    s1 = int(input("Enter first team score: "))
    s2 = int(input("Enter second team score: "))

    scores[t1] += s1 - s2
    scores[t2] += s2 - s1

    if s1 > s2:
        points[t1] += 3
    elif s2 > s1:
        points[t2] += 3
    else:
        points[t1] += 1
        points[t2] += 1

print("\n--- FINAL RANKINGS ---")

for i in range(n):
    for j in range(i + 1, n):
        if points[j] > points[i] or (
            points[j] == points[i] and scores[j] > scores[i]
        ):
            points[i], points[j] = points[j], points[i]
            scores[i], scores[j] = scores[j], scores[i]
            teams[i], teams[j] = teams[j], teams[i]

for i in range(n):
    print("Rank:", i + 1)
    print("Team:", teams[i])
    print("Points:", points[i])
    print("Tie-break value:", scores[i])
