
print("Food Waste Monitoring System")
days = int(input("Enter number of days: "))
total_waste = 0
for i in range(1, days + 1):
    print("\nDay", i)
    prepared = int(input("Meals prepared: "))
    served = int(input("Meals served: "))
    leftover = prepared - served
    total_waste += leftover
    if prepared > 0:
        percentage = leftover / prepared * 100
    else:
        percentage = 0

    print("Leftover meals:", leftover)
    print("Wastage percentage:", round(percentage, 2), "%")

    if percentage > 10:
        print("High food waste!")
    else:
        print("Food waste is acceptable.")

print("\nTotal leftover meals:", total_waste)
print("Monitoring completed!")
