
print("University Admission Decision Engine")

eligible = []

n = int(input("Enter number of applicants: "))

for i in range(n):
    print("\nApplicant", i + 1)

    name = input("Enter name: ")
    course = input("Enter course (CSE/ECE): ").upper()
    subject = input("Subject eligible? (yes/no): ").lower()
    aggregate = float(input("Enter aggregate percentage: "))
    maths = float(input("Enter Mathematics marks: "))

    if course == "CSE":
        minimum = 75
    elif course == "ECE":
        minimum = 65
    else:
        print("Invalid course!")
        continue

    if subject == "yes" and aggregate >= minimum:
        eligible.append([name, course, aggregate, maths])
        print("Eligible for admission")
    else:
        print("Not eligible for admission")

# Sort by aggregate marks, then Mathematics marks
for i in range(len(eligible)):
    for j in range(i + 1, len(eligible)):
        if (eligible[j][2] > eligible[i][2] or
            (eligible[j][2] == eligible[i][2] and
             eligible[j][3] > eligible[i][3])):

            eligible[i], eligible[j] = eligible[j], eligible[i]

print("\n--- FINAL ADMISSION RANKING ---")

if len(eligible) == 0:
    print("No eligible applicants found.")
else:
    for i in range(len(eligible)):
        print("\nRank:", i + 1)
        print("Name:", eligible[i][0])
        print("Course:", eligible[i][1])
        print("Aggregate:", eligible[i][2])
        print("Mathematics marks:", eligible[i][3])
