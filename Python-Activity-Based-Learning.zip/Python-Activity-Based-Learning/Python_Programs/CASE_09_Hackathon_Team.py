
print("Hackathon Team Formation and Ranking")

teams = []
n = int(input("Enter number of teams: "))
rounds = int(input("Enter number of rounds: "))

for i in range(n):
    print("\nTeam", i + 1)
    name = input("Enter team name: ")

    size = int(input("Enter number of members (2 to 4): "))
    while size < 2 or size > 4:
        print("Team must have 2 to 4 members.")
        size = int(input("Enter number of members: "))

    members = []
    for j in range(size):
        student_id = input("Enter student ID: ")

        while any(student_id in team["ids"] for team in teams) or student_id in members:
            print("Duplicate student ID! Enter another ID.")
            student_id = input("Enter student ID: ")

        members.append(student_id)

    total = 0
    last_score = 0

    for r in range(rounds):
        score = int(input("Enter score for round " + str(r + 1) + ": "))
        while score < 0:
            print("Score cannot be negative.")
            score = int(input("Enter score again: "))
        total += score
        last_score = score

    teams.append({
        "name": name,
        "ids": members,
        "total": total,
        "last": last_score
    })

teams.sort(key=lambda x: (x["total"], x["last"]), reverse=True)

print("\n--- FINAL RANKINGS ---")

for i in range(n):
    if i > 0 and teams[i]["total"] == teams[i-1]["total"] and teams[i]["last"] == teams[i-1]["last"]:
        rank = teams[i-1]["rank"]
    else:
        rank = i + 1

    teams[i]["rank"] = rank
    print("Rank:", rank, "| Team:", teams[i]["name"],
          "| Total Score:", teams[i]["total"])
