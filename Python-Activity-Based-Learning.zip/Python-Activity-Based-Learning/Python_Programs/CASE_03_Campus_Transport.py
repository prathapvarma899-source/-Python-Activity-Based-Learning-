print("Campus Transport Allocation")
capacity = int(input("Enter bus capacity: "))
buses = int(input("Enter available buses: "))
routes = int(input("Enter number of routes: "))
total_required = 0
total_unserved = 0
for i in range(1, routes + 1):
    passengers = int(input("Enter passengers for route " + str(i) + ": "))
    required = (passengers + capacity - 1) // capacity
    total_required += required
    if buses >= required:
        allocated = required
    else:
        allocated = buses

    buses = buses - allocated

    served = allocated * capacity

    if served > passengers:
        served = passengers

    unserved = passengers - served
    total_unserved += unserved

    print("Buses required:", required)
    print("Buses allocated:", allocated)
    print("Passengers served:", served)
    print("Unserved passengers:", unserved)

print("Total buses required:", total_required)
print("Total unserved passengers:", total_unserved)
