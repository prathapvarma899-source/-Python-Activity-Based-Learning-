
print("University Hostel Room Allocation")

rooms = []
allocated = []
duplicates = []
unallocated = []
seen_ids = []
group_rooms = {}

n = int(input("Enter number of rooms: "))

for i in range(n):
    print("\nRoom", i + 1)
    number = input("Enter room number: ")
    capacity = int(input("Enter room capacity: "))
    category = input("Enter category (Boys/Girls): ").lower()

    rooms.append({
        "number": number,
        "capacity": capacity,
        "category": category,
        "students": []
    })

s = int(input("\nEnter number of students: "))

for i in range(s):
    print("\nStudent", i + 1)

    sid = input("Enter student ID: ")
    name = input("Enter student name: ")
    category = input("Enter category (Boys/Girls): ").lower()
    group = input("Enter group name: ")

    if sid in seen_ids:
        print("Duplicate student ID!")
        duplicates.append(sid)
        continue

    seen_ids.append(sid)
    assigned = False

    for room in rooms:
        if group in group_rooms:
            if room["number"] != group_rooms[group]:
                continue

        if (room["category"] == category and
            len(room["students"]) < room["capacity"]):

            room["students"].append(name)
            allocated.append(name)

            if group not in group_rooms:
                group_rooms[group] = room["number"]

            print("Allocated to room:", room["number"])
            assigned = True
            break

    if not assigned:
        print("No suitable room available.")
        unallocated.append(name)

print("\n--- FINAL HOSTEL REPORT ---")

for room in rooms:
    print("\nRoom:", room["number"])
    print("Category:", room["category"])
    print("Capacity:", room["capacity"])
    print("Students:", room["students"])
    print("Occupied:", len(room["students"]))

print("\nTotal allocated:", len(allocated))
print("Duplicate IDs:", duplicates)
print("Total duplicate entries:", len(duplicates))
print("Unallocated students:", unallocated)
print("Total unallocated demand:", len(unallocated))
