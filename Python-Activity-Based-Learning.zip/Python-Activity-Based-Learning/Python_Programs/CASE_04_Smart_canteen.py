
print("Smart Canteen Management")

idli = 20
dosa = 15
tea = 30

sales = 0

while True:
    print("\n1. Idli - Rs.20 (Stock:", idli, ")")
    print("2. Dosa - Rs.40 (Stock:", dosa, ")")
    print("3. Tea - Rs.10 (Stock:", tea, ")")
    print("0. Finish orders")

    choice = int(input("Enter your choice: "))

    if choice == 0:
        break

    quantity = int(input("Enter quantity: "))

    if quantity <= 0:
        print("Invalid quantity!")

    elif choice == 1:
        if quantity <= idli:
            bill = quantity * 20
            idli -= quantity
            sales += bill
            print("Bill: Rs.", bill)
        else:
            print("Insufficient idli stock!")

    elif choice == 2:
        if quantity <= dosa:
            bill = quantity * 40
            dosa -= quantity
            sales += bill
            print("Bill: Rs.", bill)
        else:
            print("Insufficient dosa stock!")

    elif choice == 3:
        if quantity <= tea:
            bill = quantity * 10
            tea -= quantity
            sales += bill
            print("Bill: Rs.", bill)
        else:
            print("Insufficient tea stock!")

    else:
        print("Invalid choice!")

print("\n--- Daily Report ---")
print("Total Sales: Rs.", sales)
print("Remaining Idli:", idli)
print("Remaining Dosa:", dosa)
print("Remaining Tea:", tea)
