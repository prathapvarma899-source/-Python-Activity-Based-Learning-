
print("University Scholarship Allocation")

students = []

n = int(input("Enter number of students: "))

for i in range(n):
    print("\nStudent", i + 1)

    name = input("Enter student name: ")
    aggregate = float(input("Enter aggregate marks (%): "))
    maths = int(input("Enter Mathematics marks: "))
    science = int(input("Enter Science marks: "))
    attendance = float(input("Enter attendance (%): "))
    income = int(input("Enter family income: "))

    if (aggregate >= 75 and maths >= 60
            and science >= 60 and attendance >= 75
            and income <= 250000):
        print("Eligible for scholarship")
        students.append([name, aggregate, attendance, income])
    else:
        print("Not eligible")

# Rank students
students.sort(key=lambda x: (-x[1], -x[2], x[3]))

print("\n--- SCHOLARSHIP RANKING ---")

for i in range(len(students)):
    print("Rank:", i + 1)
    print("Name:", students[i][0])
    print("Aggregate:", students[i][1], "%")
    print("Attendance:", students[i][2], "%")
    print("Family income: Rs.", students[i][3])

print("Total eligible students:", len(students))
